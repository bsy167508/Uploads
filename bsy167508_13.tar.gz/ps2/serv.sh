cc server.c -o server
./server
