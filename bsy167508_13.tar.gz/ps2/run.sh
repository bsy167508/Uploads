cc $1".c" -o $1
./$1 localhost 5001 
