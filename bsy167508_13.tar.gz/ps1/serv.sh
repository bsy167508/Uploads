cc tcp_server.c -o server
./server
