cc tcp_client.c -o client
./client
